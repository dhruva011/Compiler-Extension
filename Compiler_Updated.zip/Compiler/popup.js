document.addEventListener('DOMContentLoaded', function () {

	document.getElementById("code").innerHTML=retrieve_Code();
	var buttonOK = document.getElementById("ok");
	buttonOK.onclick=function (){
		var lang;
		var select = document.getElementById("lang");
		if(select.selectedIndex==0){
			alert("-Select Language-");
			return;
		}
		else
		{	
				lang = select.options[select.selectedIndex].value;
		}
		var codeData = document.getElementById("code").value;
		var stdin = document.getElementById("stdin").value;
		document.getElementById('stdout').innerHTML="Compiling Your Code..."
		chrome.extension.sendMessage(codeData+"000000000000000000000"+stdin+" 000000000000000000000"+lang);	
		save_Code(codeData);
	};

	var buttonClear = document.getElementById("clear");
	buttonClear.onclick=function (){
		document.getElementById("stdin").value = "";
		document.getElementById("code").value = "";
		document.getElementById("stdout").innerHTML = "";
		document.getElementById("lang").selectedIndex=0;
	};
},false);

chrome.extension.onMessage.addListener(function (response,sender,sendResponse){
	var result = String(response);
	//alert(result);
	var stdout = result.split(",");
	var x=result.search("000000000000000000000");
	if(x==-1) {
		var time = stdout[0];
		var date = stdout[1];
		var status = stdout[2];
		var result = stdout[3];
		var memory = stdout[4];
		var signal = stdout[5];
		var public = stdout[6];
		var input = stdout[7];
		var output = stdout[8];
		var stderr = stdout[9];
		var cmpinfo = stdout[10];
		var codestatus = stdout[11];
		var timestamp = stdout[12];
		var i=0;
		var x;

		input=input.replace(/"input"/gi,'Input ');
		input=input.replace(/["]/gi,'<br>');

		output=output.replace(/"output":/gi,'Output :');
		output=output.replace(/["]/i,'<br>');

		//alert(output);
		x=[...output];
		var o="";
		for(i=0;i<x.length-1;i++){
			if(x[i]=="\\"){
				if(x[i+1]=="n"){
					o=o+"<br>";
					i++;
					continue;
				}
			}
			o=o+x[i];
		}
		

		cmpinfo=cmpinfo.replace(/["]/gi, '');
		cmpinfo=cmpinfo.replace(/[/]/gi,'');
		x = [...cmpinfo];
		var str="";
		for(i=0;i<x.length-1;i++){

			if(x[i]=="\\"){
				if(x[i+1]=="n"){
					str=str+"<br>";
					i++;
					continue;
				}
			}
			str=str+x[i];
		}

		//alert(input+"  "+output);
		str=str.split("cmpinfo");
		document.getElementById("stdout").innerHTML = input+"<br>"+o+"<br>"+"Compilation Info :"+str[1];

	}
});


function save_Code(x) {
    localStorage.code = x;
}
function clear_Code(){
	localStorage.code="";
}
function retrieve_Code(){
	return localStorage.code;
}