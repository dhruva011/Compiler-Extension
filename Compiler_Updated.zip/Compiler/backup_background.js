$(function(){
	var data;
	var http = new XMLHttpRequest();
	var url="https://www.codechef.com/api/ide/run/all/";
	var param="sourceCode=%23include+%3Ciostream%3E%0Ausing+namespace+std%3B%0A%0Aint+main()+%7B%0A%09%2F%2F+your+code+goes+here%0A%09cout%3C%3C%22TheQuickBrownFox%22%3B%0A%09return+0%3B%0A%7D%0A&language=1";
	http.open("POST", url, false);
	http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	//http.setRequestHeader("Content-Length", param.length);
	http.onreadystatechange = function() {//Call a function when the state changes.
    if(http.readyState == 4 && http.status == 200)
        data = http.responseText;
    	//console.log(data);
	}
	http.send(param);


	//var timestamp = data.split(",");
//	timestamp = String(timestamp[1].split(":"));
	data = data.split(",");
	var fullTimeStamp = data[1];
	var code = fullTimeStamp.split(":");
	var finalTimeStamp = code[1];
	//console.log(code[1]);
	var temp,z,x;
	//finalTimeStamp contains the url hashcodes
	http = new XMLHttpRequest();
	var x="https://www.codechef.com/api/ide/run/all?timestamp=";
	url = x.concat(finalTimeStamp);
	//console.log("Now going to send A GET Request to = "+url);
	http.open("GET", url, false);
	http.onreadystatechange = function() {//Call a function when the state changes.
    if(http.readyState == 4 && http.status == 200){
    	temp=String(http.responseText)
    	//console.log(temp.length);
    	if(temp.length>72){
    		console.log("Response Found= "+http.responseText);
    		clearInterval(t);
    		clearInterval(z);
    		return;
    	}
    }        
	}
	http.send();
		t=setTimeout(function loop(){
		http.open("GET", url, true);
		http.send();
		z=setTimeout(loop,2000)}, 2000);
	
});

chrome.extension.onMessage.addListener(function (response,sender,sendResponse){
	//alert("From Background Script");
	var d = fixedEncodeURIComponent(response);
	alert(d);
});

function fixedEncodeURIComponent(str){
     return encodeURIComponent(str).replace(/[!'()]/g, escape).replace(/\*/g, "%2A");
}

