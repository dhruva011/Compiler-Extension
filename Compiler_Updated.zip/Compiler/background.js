chrome.extension.onMessage.addListener(function (response,sender,sendResponse){
	//alert("Background Script Invoked and response = "+response);
	var s = String(response);
	var arr = s.split("000000000000000000000");
	var code;
	var stdin=null;
	var lang=null;
	if(arr.length>1)
	{
		code=arr[0];
		stdin=arr[1];
		lang=arr[2];
	}
	if(code==undefined)
		return;
	
	var formatCode = String(fixedEncodeURIComponent(code));
	var formatInput = String(fixedEncodeURIComponent(stdin));
	var param = "sourceCode="+formatCode+"&language="+lang+"&input="+formatInput;
	//alert("lang for Request = "+lang);
	process(param);
	//alert("Code:"+code+" stdin:"+formatInput+" lang:"+lang);
});

function fixedEncodeURIComponent(str){
     return encodeURIComponent(str).replace(/[!'()]/g, escape).replace(/\*/g, "%2A");
}

function process(param)
{
	//alert("Process Function Invoked");
	var http = new XMLHttpRequest();
	var url="https://www.codechef.com/api/ide/run/all/";
	//First POST Request with Parameter
	http.open("POST", url, false);
	http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	http.onreadystatechange = function() {//Call a function when the state changes.
    if(http.readyState == 4 && http.status == 200)
        data = http.responseText;
	}
	http.send(param);
	//Finding out the Time Stamp Code from POST Response
	data = data.split(",");
	var fullTimeStamp = data[1];
	var code = fullTimeStamp.split(":");
	var finalTimeStamp = code[1];
	var temp,z,x;
	//finalTimeStamp contains the url hashcodes
	var httpnew = new XMLHttpRequest();
	var x="https://www.codechef.com/api/ide/run/all?timestamp=";
	url = x.concat(finalTimeStamp);
	//console.log("Now going to send A GET Request to = "+url);
	httpnew.open("GET", url, false);
		//httpnew.send();
		t=setInterval(function loop(){
		httpnew.open("GET", url, true);
		httpnew.send();
		httpnew.onreadystatechange = function() 
		{//Call a function when the state changes.
   		 if(httpnew.readyState == 4 && httpnew.status == 200)
  		  {
   		 	temp=String(httpnew.responseText)
    		var x = temp.search("result");
    		if(x!=-1)
    		{
    			//alert("I am inside the setInterval : "+httpnew.responseText);
    			//console.log("Response Found= "+httpnew.responseText);
    			chrome.extension.sendMessage(httpnew.responseText);	
    			clearInterval(t);
    			//clearInterval(z);
    			//return;
    		}
      	}        
		}
		}, 2000);
}